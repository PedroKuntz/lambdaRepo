package com.itau.cartaobranco.repository

import com.amazonaws.services.dynamodbv2.document.Item
import com.amazonaws.services.lambda.runtime.events.SQSEvent
import com.itau.cartaobranco.configuration.DatabaseConfiguration

class TransactionRepository {

    private val dynamoDB = DatabaseConfiguration.clientDatabase()

    fun save(input: SQSEvent) {
        val table = dynamoDB.getTable("transaction-event")

        val item = Item()
            .withPrimaryKey("transactionId", input.records.first().messageId)
            .withString("transaction", input.records.first().body)

        // Write the item to the table
        val outcome = table.putItem(item)
    }
}