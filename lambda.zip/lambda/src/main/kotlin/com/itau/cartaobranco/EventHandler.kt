package com.itau.cartaobranco

import com.amazonaws.services.lambda.runtime.Context
import com.amazonaws.services.lambda.runtime.RequestHandler
import com.amazonaws.services.lambda.runtime.events.SQSEvent
import com.itau.cartaobranco.repository.TransactionRepository

class EventHandler: RequestHandler<SQSEvent, String> {

    val transactionRepository = TransactionRepository()

    override fun handleRequest(input: SQSEvent?, context: Context?): String {
        if (context != null && input != null ) {
            val logger = context.logger
            logger.log("SQSEVENT: -> $input")
            transactionRepository.save(input)
        }
        return "TESTE"
    }
}