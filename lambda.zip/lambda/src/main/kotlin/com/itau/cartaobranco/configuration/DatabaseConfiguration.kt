package com.itau.cartaobranco.configuration

import com.amazonaws.auth.AWSStaticCredentialsProvider
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.regions.Regions
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder
import com.amazonaws.services.dynamodbv2.document.DynamoDB

object DatabaseConfiguration {

    fun clientDatabase() : DynamoDB{
        val client = AmazonDynamoDBClientBuilder
            .standard()
            .withRegion(Regions.US_EAST_1)
            .withCredentials(
                AWSStaticCredentialsProvider(
                    BasicAWSCredentials("", "")
                )
            )
            .build()
        return DynamoDB(client)
    }
}