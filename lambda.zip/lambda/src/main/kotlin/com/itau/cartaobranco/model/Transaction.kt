package com.itau.cartaobranco.model

import com.beust.klaxon.Json
import java.util.*

class Transaction(@Json val id: String = UUID.randomUUID().toString(),
                  @Json val firstName: String,
                  @Json val lastName: String,
                  @Json val age: Int,
                  @Json val address: String?)

